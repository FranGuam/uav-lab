## 文件说明
- arena_1.world
将其放在src/hector_gazebo/hector_gazebo_worlds/worlds/目录下替换掉arena_1.world即可（建议备份一下原来的arena_1.world）。此文件会在仿真任务验收规则中规定的五个位置都放上小球方便调试，同学们也可以在这个文件中修改球的颜色（sphere_*的<material>属性）来模拟不同情况。

- set_model_state.py
运行 "python3 set_model_state.py quadrotor 1 1 1.57" 可以将无人机放置在起始点。其中参数"quadrotor"为无人机模型的名字，"1 1 1.57"表示放置在起始点（1，1），yaw角为pi/2。
